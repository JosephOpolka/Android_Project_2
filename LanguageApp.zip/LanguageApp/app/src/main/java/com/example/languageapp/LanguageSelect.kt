package com.example.languageapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView

class LanguageSelect : AppCompatActivity() {

    private lateinit var topicTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.language_select)

        val japanButton = findViewById<ImageButton>(R.id.language_button_japan)
        japanButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            intent.putExtra("language", "Japanese")
            startActivity(intent)
        }
        val spainButton = findViewById<ImageButton>(R.id.language_button_spain)
        spainButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            intent.putExtra("language", "Spanish")
            startActivity(intent)
        }
        val germanButton = findViewById<ImageButton>(R.id.language_button_germany)
        germanButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            intent.putExtra("language", "German")
            startActivity(intent)
        }
    }
}