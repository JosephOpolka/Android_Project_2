package com.example.languageapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class TopicSelect : AppCompatActivity() {

    private lateinit var topicTitle: TextView
    private var selectedLanguage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.topic_select)

        topicTitle = findViewById(R.id.topic_title)
        selectedLanguage = intent.getStringExtra("language")
        updateTopicTitle()

        val backButton = findViewById<Button>(R.id.topicselect_button_back)
        backButton.setOnClickListener {
            val intent = Intent(this, LanguageSelect::class.java)
            startActivity(intent)
        }

        val animalButton = findViewById<Button>(R.id.topic_button_animal)
        animalButton.setOnClickListener {
            val intent = Intent(this, TopicTemplate::class.java)
            intent.putExtra("language", selectedLanguage)
            intent.putExtra("topic", "animal")
            startActivity(intent)
        }

        val machineButton = findViewById<Button>(R.id.topic_button_machine)
        machineButton.setOnClickListener {
            val intent = Intent(this, TopicTemplate::class.java)
            intent.putExtra("language", selectedLanguage)
            intent.putExtra("topic", "machine")
            startActivity(intent)
        }

        val materialButton = findViewById<Button>(R.id.topic_button_material)
        materialButton.setOnClickListener {
            val intent = Intent(this, TopicTemplate::class.java)
            intent.putExtra("language", selectedLanguage)
            intent.putExtra("topic", "material")
            startActivity(intent)
        }

        val furnitureButton = findViewById<Button>(R.id.topic_button_furniture)
        furnitureButton.setOnClickListener {
            val intent = Intent(this, TopicTemplate::class.java)
            intent.putExtra("language", selectedLanguage)
            intent.putExtra("topic", "furniture")
            startActivity(intent)
        }

        val startButton = findViewById<Button>(R.id.topicselect_button_start)
        startButton.setOnClickListener {
            val intent = Intent(this, QuizTemplate::class.java)
            intent.putExtra("language", selectedLanguage)
            startActivity(intent)
        }
    }

    private fun updateTopicTitle() {
        val learningLanguage = selectedLanguage?.let { "Learning $it" } ?: ""
        topicTitle.text = learningLanguage
    }
}