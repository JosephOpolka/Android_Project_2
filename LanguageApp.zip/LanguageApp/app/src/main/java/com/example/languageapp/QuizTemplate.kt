package com.example.languageapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView

class QuizTemplate : AppCompatActivity() {

    private lateinit var returnButton: Button
    private lateinit var titleLanguage: TextView
    private lateinit var titleTopic: TextView
    private lateinit var q1: RadioButton
    private lateinit var q2: RadioButton
    private lateinit var q3: RadioButton
    private lateinit var q4: RadioButton
    private var selectedLanguage: String? = null
    private var randomizedTopic: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz_template)

        titleLanguage = findViewById(R.id.quiz_title_language)
        titleTopic = findViewById(R.id.quiz_title_topic)
        q1 = findViewById(R.id.q1)
        q2 = findViewById(R.id.q2)
        q3 = findViewById(R.id.q3)
        q4 = findViewById(R.id.q4)

        returnButton = findViewById<Button>(R.id.quiz_button_return)
        returnButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            intent.putExtra("language", selectedLanguage)
            startActivity(intent)
        }

        // Retrieve the selected language from the intent extras
        selectedLanguage = intent.getStringExtra("language")

        // Set the title with selected language and randomized topic
        setQuizTitle(selectedLanguage)

        // Set the questions and options based on the selected language
        setQuizQuestions(selectedLanguage)

        // Enable submit button to show correct answers
        val submitButton = findViewById<Button>(R.id.submit_button)
        submitButton.setOnClickListener {
            showCorrectAnswers()
        }
    }

    private fun setQuizTitle(language: String?) {
        randomizedTopic = getRandomTopic()
        val languageText = when (language) {
            "Japanese" -> "In Japanese,"
            "Spanish" -> "In Spanish,"
            "German" -> "In German,"
            else -> "In Language,"
        }
        val topicText = when (randomizedTopic) {
            "animal" -> "which of the following is an Animal?"
            "machine" -> "which of the following is a Machine?"
            "material" -> "which of the following is Material?"
            "furniture" -> "which of the following is Furniture?"
            else -> "which of the following is a Topic?"
        }
        titleLanguage.text = languageText
        titleTopic.text = topicText
    }

    private fun getRandomTopic(): String {
        val topics = listOf("animal", "machine", "material", "furniture")
        return topics.random()
    }

    private fun setQuizQuestions(language: String?) {
        val translations = getTranslations(language)

        q1.text = translations[0]
        q2.text = translations[1]
        q3.text = translations[2]
        q4.text = translations[3]
    }

    private fun getTranslations(language: String?): List<String> {
        return when (language) {
            "Japanese" -> listOf("Neko", "Kuruma", "Ki", "Terebi")
            "Spanish" -> listOf("Gato", "Auto", "Madera", "Televisor")
            "German" -> listOf("Katse", "Auto", "Holz", "Fernsehen")
            else -> listOf("", "", "", "")
        }
    }

    private fun showCorrectAnswers() {
        val correctAnswers = getCorrectAnswers(selectedLanguage, randomizedTopic)

        // Disable all radio buttons
        q1.isEnabled = false
        q2.isEnabled = false
        q3.isEnabled = false
        q4.isEnabled = false

        // Set the correct answer text to green
        when (correctAnswers.indexOf(true)) {
            0 -> q1.setTextColor(resources.getColor(R.color.green))
            1 -> q2.setTextColor(resources.getColor(R.color.green))
            2 -> q3.setTextColor(resources.getColor(R.color.green))
            3 -> q4.setTextColor(resources.getColor(R.color.green))
        }

        // Set the incorrect answer texts to light gray
        if (!correctAnswers[0]) q1.setTextColor(resources.getColor(R.color.light_gray))
        if (!correctAnswers[1]) q2.setTextColor(resources.getColor(R.color.light_gray))
        if (!correctAnswers[2]) q3.setTextColor(resources.getColor(R.color.light_gray))
        if (!correctAnswers[3]) q4.setTextColor(resources.getColor(R.color.light_gray))
    }

    private fun getCorrectAnswers(language: String?, topic: String?): List<Boolean> {
        return when (language) {
            "Japanese" -> when (topic) {
                "animal" -> listOf(true, false, false, false)
                "machine" -> listOf(false, true, false, false)
                "material" -> listOf(false, false, true, false)
                "furniture" -> listOf(false, false, false, true)
                else -> listOf(false, false, false, false)
            }
            "Spanish" -> when (topic) {
                "animal" -> listOf(true, false, false, false)
                "machine" -> listOf(false, true, false, false)
                "material" -> listOf(false, false, true, false)
                "furniture" -> listOf(false, false, false, true)
                else -> listOf(false, false, false, false)
            }
            "German" -> when (topic) {
                "animal" -> listOf(true, false, false, false)
                "machine" -> listOf(false, true, false, false)
                "material" -> listOf(false, false, true, false)
                "furniture" -> listOf(false, false, false, true)
                else -> listOf(false, false, false, false)
            }
            else -> listOf(false, false, false, false)
        }
    }
}