package com.example.languageapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class TopicTemplate : AppCompatActivity() {

    private lateinit var backButton: Button
    private lateinit var titleView: TextView
    private lateinit var english1TextView: TextView
    private lateinit var english2TextView: TextView
    private lateinit var english3TextView: TextView
    private lateinit var topicItem1TextView: TextView
    private lateinit var topicItem2TextView: TextView
    private lateinit var topicItem3TextView: TextView
    private var selectedLanguage: String? = null
    private var selectedTopic: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.topic_template)

        english1TextView = findViewById(R.id.english_1)
        english2TextView = findViewById(R.id.english_2)
        english3TextView = findViewById(R.id.english_3)
        topicItem1TextView = findViewById(R.id.topic_item_1)
        topicItem2TextView = findViewById(R.id.topic_item_2)
        topicItem3TextView = findViewById(R.id.topic_item_3)
        titleView = findViewById(R.id.topic_titled)
        backButton = findViewById(R.id.topic_button_back)


        // Retrieve the selected language from the intent extras
        selectedLanguage = intent.getStringExtra("language")

        // Set the English translations based on the selected topic and language
        selectedTopic = intent.getStringExtra("topic")
        setTranslations(selectedTopic, selectedLanguage)

        backButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            intent.putExtra("language", selectedLanguage)
            startActivity(intent)
        }
    }

    private fun setTranslations(topic: String?, language: String?) {
        when (topic) {
            "animal" -> setAnimalTranslations(language)
            "machine" -> setMachineTranslations(language)
            "material" -> setMaterialTranslations(language)
            "furniture" -> setFurnitureTranslations(language)
            else -> {
                // Handle unknown topic or default case
            }
        }
    }

    private fun setAnimalTranslations(language: String?) {
        when (language) {
            "Japanese" -> {
                topicItem1TextView.text = "Neko"
                topicItem2TextView.text = "Inu"
                topicItem3TextView.text = "Uma"
            }
            "Spanish" -> {
                topicItem1TextView.text = "Gato"
                topicItem2TextView.text = "Perro"
                topicItem3TextView.text = "Caballo"
            }
            "German" -> {
                topicItem1TextView.text = "Katse"
                topicItem2TextView.text = "Hund"
                topicItem3TextView.text = "Pferd"
            }
        }
        // Set the English translations
        english1TextView.text = "Cat"
        english2TextView.text = "Dog"
        english3TextView.text = "Horse"
        titleView.text = "Animals"
    }

    private fun setMachineTranslations(language: String?) {
        when (language) {
            "Japanese" -> {
                topicItem1TextView.text = "Kuruma"
                topicItem2TextView.text = "Boto"
                topicItem3TextView.text = "Hikoki"
            }
            "Spanish" -> {
                topicItem1TextView.text = "Auto"
                topicItem2TextView.text = "Bote"
                topicItem3TextView.text = "Avion"
            }
            "German" -> {
                topicItem1TextView.text = "Auto"
                topicItem2TextView.text = "Boot"
                topicItem3TextView.text = "Ebene"
            }
        }
        // Set the English translations
        english1TextView.text = "Car"
        english2TextView.text = "Boat"
        english3TextView.text = "Airplane"
        titleView.text = "Machines"
    }

    private fun setMaterialTranslations(language: String?) {
        when (language) {
            "Japanese" -> {
                topicItem1TextView.text = "Ki"
                topicItem2TextView.text = "Kinzoku"
                topicItem3TextView.text = "Nuno"
            }
            "Spanish" -> {
                topicItem1TextView.text = "Madera"
                topicItem2TextView.text = "Metal"
                topicItem3TextView.text = "Pano"
            }
            "German" -> {
                topicItem1TextView.text = "Holz"
                topicItem2TextView.text = "Metall"
                topicItem3TextView.text = "Tuch"
            }
        }
        // Set the English translations
        english1TextView.text = "Wood"
        english2TextView.text = "Metal"
        english3TextView.text = "Cloth"
        titleView.text = "Materials"
    }

    private fun setFurnitureTranslations(language: String?) {
        when (language) {
            "Japanese" -> {
                topicItem1TextView.text = "Terebi"
                topicItem2TextView.text = "Isu"
                topicItem3TextView.text = "Ranpu"
            }
            "Spanish" -> {
                topicItem1TextView.text = "Televisor"
                topicItem2TextView.text = "Silla"
                topicItem3TextView.text = "Lampara"
            }
            "German" -> {
                topicItem1TextView.text = "Fernsehen"
                topicItem2TextView.text = "Stuhl"
                topicItem3TextView.text = "Lampe"
            }
        }
        // Set the English translations
        english1TextView.text = "Television"
        english2TextView.text = "Chair"
        english3TextView.text = "Lamp"
        titleView.text = "Furniture"
    }
}
